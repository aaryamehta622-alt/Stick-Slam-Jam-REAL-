# Architecture
- Keep move effects in dedicated presentation modules driven by accepted combat actions; rendering must never alter damage, cooldowns or hit detection.
- Use procedural canvas geometry for combat VFX so effects remain animated and consistent with the pixel-art renderer.